package Pruebas;

import Controlador.JuegoController;
import Dominio.*;
import ENUM.EstadoFicha;
import Vista.VistaJuego;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Prueba2 {

    public static void main(String[] args) {

        // Clase auxiliar de preparación
        PruebasPreparacion preparar = new PruebasPreparacion();
        // Preparar jugadores
        List<Jugador> jugadores = preparar.crearJugadores();
        // Preparar tablero
        Tablero tablero = preparar.crearTablero();
        // Crear partida
        Partida modelo = new Partida(1L, jugadores);
        modelo.setTablero(tablero);

        // Crear turno y le agregamos al jugador seleccionado
        Turno turnoPrueba = new Turno(jugadores.get(0));
        modelo.setTurnoActual(turnoPrueba);

        // Creamos vista y la agregamos a los subscriptores de modelo
        VistaJuego vista = new VistaJuego();
        modelo.agregarObserver(vista);

        // Creamos el controlador
        JuegoController controlador = new JuegoController(vista, modelo);

        // --- 3. CICLO DEL JUEGO (GAME LOOP) ---
        Scanner scanner = new Scanner(System.in);
        boolean jugando = true;

        System.out.println("\n=======================================");
        System.out.println("    BIENVENIDO A PARCHÍS   ");
        System.out.println("=======================================");

        while (jugando) {

            Jugador jugadorActivo = modelo.getTurnoActual().getJugadorActual();

            System.out.println("\n--- TURNO DE: " + jugadorActivo.getNombre() + " ---");
            System.out.println("¿Qué acción deseas realizar?");
            System.out.println("1. Lanzar Dado");
            System.out.println("2. Ver estado actual de mis fichas");
            System.out.println("3. Salir del juego");
            System.out.print("Elige una opción (1-3): ");

            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1":

                    System.out.println("\n🎲 Solicitando al sistema lanzar el dado...");
                    controlador.solicitarTirada();

                case "2":
                    System.out.println("\n>> ESTADO DE FICHAS:");
                    for (Ficha f : modelo.getTurnoActual().getJugadorActual().getFichas()) {
                        System.out.println("   Ficha " + f.getIdFicha() + " -> " + f.getEstado());
                    }
                    break;

                case "3":
                    System.out.println("\nCerrando el motor del juego... ¡Hasta luego!");
                    jugando = false;
                    break;

                default:
                    System.out.println("\n Opción no válida. Escribe 1, 2 o 3.");
            }
        }
        scanner.close();

    }

}
