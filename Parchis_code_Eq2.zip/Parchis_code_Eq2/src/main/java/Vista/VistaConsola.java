package Vista;

import Modelo.IPartida;

public class VistaConsola {

    private final IPartida modelo;

    public VistaConsola(IPartida modelo) {
        this.modelo = modelo;
    }

}
