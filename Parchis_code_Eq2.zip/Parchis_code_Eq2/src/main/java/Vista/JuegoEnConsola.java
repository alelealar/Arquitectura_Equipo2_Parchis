
package Vista;

import Dominio.Jugador;
import Dominio.Partida;
import ENUM.ColorJugador;
import Modelo.IPartida;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author oliro
 */
public class JuegoEnConsola {

    private final IPartida modelo;

    public JuegoEnConsola(IPartida modelo) {
        this.modelo = modelo;
    }

    public void iniciar() {
        System.out.print("Juego con 4 jugadores");
        Partida partida = new Partida(1L, crearJugadores(4));
        // VistaConsola vista = new VistaConsola(partida);

    }

    private List<Jugador> crearJugadores(int cantidad) {
        List<Jugador> jugadores = new ArrayList<>();
        jugadores.add(new Jugador(1L, "Oliver Robles", ColorJugador.ROJO, "avatar"));
        jugadores.add(new Jugador(2L, "Alejandra Leal", ColorJugador.AZUL, "avatar"));
        jugadores.add(new Jugador(3L, "Valeria Gutierrez", ColorJugador.AMARILLO, "avatar"));
        jugadores.add(new Jugador(4L, "Julian Gracia", ColorJugador.MORADO, "avatar"));
        return jugadores;
    }

}
